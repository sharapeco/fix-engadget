# Fix Engadget

Suppress unnecessary redirecting: engadget.com -> guce.engadget.com -> guce.advertising.com -> engadget.com
